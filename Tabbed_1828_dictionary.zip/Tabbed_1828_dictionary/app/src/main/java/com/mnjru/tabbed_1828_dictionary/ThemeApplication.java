package com.mnjru.tabbed_1828_dictionary;

import android.app.Application;

/**
 * Created by mnjru on 1/6/2018.
 */

public class ThemeApplication extends Application {
    public static int currentPosition;
}
